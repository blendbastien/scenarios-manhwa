/* Scénarios Manhwa — The Last Horizon (Foundry v13) : outil MJ, calque joueur, journal des scénarios, récompenses. */
const MID = "scenarios-manhwa";
const SOCKET = `module.${MID}`;
const { ApplicationV2 } = foundry.applications.api;
const C = () => window.SM_CARD;

/* ═══════════ réglages ═══════════ */
Hooks.once("init", () => {
  const R = (k, o) => game.settings.register(MID, k, o);
  R("scenarios", { scope: "world", config: false, type: Array, default: [] });
  R("playersSeeDone", { name: "Les joueurs voient les scénarios terminés", hint: "Si activé, les scénarios terminés ou échoués marqués « visible » restent consultables dans le journal des joueurs.", scope: "world", config: true, type: Boolean, default: true });
  R("playersCanOpen", { name: "Les joueurs peuvent ouvrir le journal des scénarios", scope: "world", config: true, type: Boolean, default: true });
  R("notifyStatus", { name: "Notifier les changements de statut", hint: "Quand un scénario passe en cours / terminé / échoué, une notification est envoyée aux joueurs (via Notifications Manhwa si le module est actif, sinon la carte du scénario est ré-affichée).", scope: "world", config: true, type: Boolean, default: true });
  R("statusText", { name: "Texte de notification — statut", hint: "Variables : {titre} {type} {num} {statut}", scope: "world", config: true, type: String, default: "[ {type} « {titre} » : {statut}. ]" });
  R("rewardText", { name: "Texte de notification — récompense", hint: "Variables : {titre} {perso} {gold} {pi} {objets}", scope: "world", config: true, type: String, default: "[ {perso} reçoit {gold} G · {pi} P.I. · {objets} pour « {titre} ». ]" });
  R("goldPath", { name: "Champ du Gold", hint: "Clé system.props.<clé> du portefeuille. Laisser vide pour reprendre celui de la Fiche Manhwa.", scope: "world", config: true, type: String, default: "" });
  R("piPath", { name: "Champ des P.I. (Pièces Interstellaires)", hint: "Clé system.props.<clé>.", scope: "world", config: true, type: String, default: "pi" });
  R("dimBackground", { name: "Assombrir l'écran derrière la carte", scope: "client", config: true, type: Boolean, default: true });
  R("duration", { name: "Durée d'affichage de la carte (s) · 0 = jusqu'au clic", scope: "world", config: true, type: Number, default: 0 });
  R("position", { name: "Position de la carte", scope: "world", config: true, type: String, choices: { center: "Centre", top: "Haut", bottom: "Bas" }, default: "center" });
  R("scale", { name: "Échelle de la carte (%)", scope: "client", config: true, type: Number, default: 115 });
  R("sound", { name: "Son à l'affichage (chemin Foundry, vide = son du module)", scope: "world", config: true, type: String, default: `modules/${MID}/sounds/scenario.ogg`, filePicker: "audio" });
  R("volume", { name: "Volume (0–1)", scope: "client", config: true, type: Number, default: 0.7, range: { min: 0, max: 1, step: 0.05 } });
  R("chat", { name: "Copier la carte dans le chat à la diffusion", scope: "world", config: true, type: Boolean, default: true });
});

/* ═══════════ données ═══════════ */
const all = () => (game.settings.get(MID, "scenarios") || []).map(s => C().normalize(s));
async function saveAll(list) { await game.settings.set(MID, "scenarios", list); }
function visibleFor(user) {
  const list = all(); if (user.isGM) return list;
  const seeDone = game.settings.get(MID, "playersSeeDone");
  return list.filter(s => s.status === "active" || (seeDone && s.visible !== false && (s.status === "done" || s.status === "failed"))).map(s => { const c = { ...s }; delete c.notes; delete c.rew; return c; });
}
function goldPath() { const g = game.settings.get(MID, "goldPath"); if (g) return g; try { return game.settings.get("fiche-manhwa", "goldPath") || "gold"; } catch (e) { return "gold"; } }
function playerActors() {
  return game.actors.filter(a => a.hasPlayerOwner).map(a => {
    const owner = game.users.find(u => !u.isGM && a.testUserPermission(u, "OWNER"));
    const gp = goldPath(), pp = game.settings.get(MID, "piPath");
    return { id: a.id, name: a.name, img: a.img, owner: owner?.name || "", gold: foundry.utils.getProperty(a, `system.props.${gp}`) ?? null, pi: foundry.utils.getProperty(a, `system.props.${pp}`) ?? null };
  });
}
function users() { return game.users.filter(u => !u.isGM).map(u => ({ id: u.id, name: u.name, color: u.color?.toString?.() || u.color, active: u.active })); }
function catalogueList() {
  try { const cat = game.modules.get("last-horizon-catalogue"); if (!cat?.active || !cat.api?.getDB) return []; const db = cat.api.getDB() || {}; return (db.items || []).map(e => ({ id: e.id, n: e.n, rang: e.rang, t: e.t, price: e.price })); } catch (e) { return []; }
}

/* ═══════════ calque joueur ═══════════ */
let layerEl = null, hideTimer = null, queue = [], showing = false;
function layer() { if (layerEl) return layerEl; layerEl = document.createElement("div"); layerEl.id = "sm-layer"; document.body.appendChild(layerEl); return layerEl; }
function playSound() { const src = game.settings.get(MID, "sound"); if (!src) return; try { foundry.audio.AudioHelper.play({ src, volume: game.settings.get(MID, "volume"), autoplay: true, loop: false }, false); } catch (e) { try { AudioHelper.play({ src, volume: game.settings.get(MID, "volume"), autoplay: true, loop: false }, false); } catch (e2) {} } }
function showCard(scen, opts = {}) {
  if (showing) { queue.push([scen, opts]); return; }
  showing = true; const L = layer(); L.innerHTML = "";
  const dim = game.settings.get(MID, "dimBackground"); const pos = game.settings.get(MID, "position"); const scale = (game.settings.get(MID, "scale") || 100) / 100;
  if (dim) { const d = document.createElement("div"); d.className = "sm-dim"; L.appendChild(d); }
  const w = document.createElement("div"); w.className = `sm-wrap pos-${pos}`; w.style.transform = `scale(${scale})`;
  w.innerHTML = C().html(scen, { cls: "live" }) + `<div class="sm-hint">CLIQUER POUR FERMER · CONSULTABLE DANS LE JOURNAL DES SCÉNARIOS</div>`;
  L.appendChild(w);
  const close = () => { if (!showing) return; w.classList.add("out"); setTimeout(() => { L.innerHTML = ""; showing = false; if (queue.length) { const n = queue.shift(); showCard(n[0], n[1]); } }, 360); clearTimeout(hideTimer); };
  w.addEventListener("click", close); L.querySelector(".sm-dim")?.addEventListener("click", close);
  const dur = Number(game.settings.get(MID, "duration")) || 0; if (dur > 0) hideTimer = setTimeout(close, dur * 1000);
  if (!opts.silent) playSound();
}
function receive(p) {
  if (!p || p.type !== "show") return;
  const t = p.targets; if (t !== "all" && Array.isArray(t) && !t.includes(game.user.id) && !(game.user.isGM && p.gmToo)) return;
  if (game.user.isGM && !p.gmToo) return;
  showCard(p.scen);
  for (const app of Object.values(ui.windows)) if (app instanceof ScenJournal) app.render(false);
  foundry.applications.instances?.forEach?.(a => { if (a instanceof ScenJournal) a.render(false); });
}
function broadcast(scen, targets = "all", gmToo = true) {
  const payload = { type: "show", scen, targets, gmToo };
  game.socket.emit(SOCKET, payload); receive(payload);
  if (game.settings.get(MID, "chat")) chatCard(scen);
}
function chatCard(s) {
  const wr = C().worldRef(s); const T = C().TYPE_LABELS[s.type] || s.type;
  const html = `<div class="sm-chat" style="border:1px solid #2a3c6a;border-left:4px solid ${wr[2]};border-radius:4px;padding:8px 10px;background:#070f20;color:#cfe0ff;font-family:'Signika',sans-serif">
    <div style="font-size:10px;letter-spacing:.2em;color:#38e0ff">${T}${s.type === "PRINCIPAL" ? " · N°" + s.num : ""} · RANG ${s.rang}</div>
    <div style="font-size:15px;font-weight:700;color:${s.titreCol || "#fff"};margin:3px 0">${foundry.utils.escapeHTML(s.titre || s.cible || "")}</div>
    ${s.success ? `<div><b style="color:#3dffa0">◈ Réussite :</b> ${foundry.utils.escapeHTML(s.success)}</div>` : ""}${s.fail ? `<div><b style="color:#ff4d6a">✕ Échec :</b> ${foundry.utils.escapeHTML(s.fail)}</div>` : ""}${s.time ? `<div><b style="color:#ffd34d">◷ Limite :</b> ${foundry.utils.escapeHTML(s.time)}</div>` : ""}${s.rewards ? `<div><b style="color:#f0c46a">✦ Récompense :</b> ${foundry.utils.escapeHTML(s.rewards)}</div>` : ""}
    <div style="font-size:9px;letter-spacing:.14em;color:#4a6a9e;margin-top:4px">MONDE ${wr[0]} · ${wr[1]}</div></div>`;
  ChatMessage.create({ content: html, speaker: { alias: "Système" } });
}

/* ═══════════ notifications (statut, récompenses) ═══════════ */
function tpl(s, v) { return String(s || "").replace(/\{(\w+)\}/g, (m, k) => (v[k] ?? m)); }
function notifyPlayers(text, scen) {
  const nm = game.modules.get("notifications-manhwa");
  if (nm?.active && nm.api?.notify) { nm.api.notify({ text, theme: "or", font: "system", duration: 8, position: "top", width: 700, chat: false, targets: "all", gmToo: true, top: "SYS::SCENARIO_LINK", bot: "SCENARIO.NETWORK · STATUS.SYS", sound: "neutral" }); return true; }
  if (scen) broadcast(scen, "all", true); else ChatMessage.create({ content: `<div style="font-family:'Signika';color:#38e0ff">${foundry.utils.escapeHTML(text)}</div>`, speaker: { alias: "Système" } });
  return false;
}
async function grantRewards(m) {
  const list = all(); const s = list.find(x => x.id === m.scenId); const gp = goldPath(), pp = game.settings.get(MID, "piPath");
  const cat = game.modules.get("last-horizon-catalogue"); const db = cat?.active && cat.api?.getDB ? (cat.api.getDB() || {}) : {};
  let mapping = null; try { mapping = foundry.utils.mergeObject(foundry.utils.deepClone(game.settings.get("last-horizon-catalogue", "mapping") || {}), {}); } catch (e) {}
  const results = [];
  for (const id of m.actorIds || []) {
    const a = game.actors.get(id); if (!a) continue; const upd = {};
    if (m.gold) upd[`system.props.${gp}`] = (Number(foundry.utils.getProperty(a, `system.props.${gp}`)) || 0) + Number(m.gold);
    if (m.pi) upd[`system.props.${pp}`] = (Number(foundry.utils.getProperty(a, `system.props.${pp}`)) || 0) + Number(m.pi);
    if (Object.keys(upd).length) await a.update(upd);
    const names = [];
    for (const it of m.items || []) {
      const e = (db.items || []).find(x => x.id === it.id); if (!e || !cat.api?.itemData) { names.push(`${it.n} (introuvable au catalogue)`); continue; }
      const data = await cat.api.itemData(e, mapping || {}, db); if (!data) continue;
      for (let q = 0; q < (it.qty || 1); q++) await a.createEmbeddedDocuments("Item", [data]);
      names.push(`${it.qty > 1 ? it.qty + "× " : ""}${e.n}`);
    }
    results.push({ actor: a.name, names });
    const text = tpl(game.settings.get(MID, "rewardText"), { titre: m.title || s?.titre || "", perso: a.name, gold: m.gold || 0, pi: m.pi || 0, objets: names.length ? names.join(", ") : "aucun objet" });
    if (game.settings.get(MID, "notifyStatus")) notifyPlayers(text, null);
  }
  return results;
}

/* ═══════════ outil MJ (iframe) ═══════════ */
class ScenTool extends ApplicationV2 {
  static DEFAULT_OPTIONS = { id: "sm-tool", classes: ["lh-frame", "sm-frame"], window: { title: "Scénarios Manhwa — Tableau des scénarios", icon: "fa-solid fa-scroll", resizable: true, minimizable: true }, position: { width: 1360, height: 900 } };
  async _prepareContext() { return {}; }
  async _renderHTML() { const f = document.createElement("iframe"); f.className = "sm-iframe"; f.src = `modules/${MID}/app/scen.html`; f.setAttribute("allow", "clipboard-write"); this.frame = f; return f; }
  _replaceHTML(r, c) { c.replaceChildren(r); }
  post(m) { try { this.frame?.contentWindow?.postMessage(m, "*"); } catch (e) {} }
  initData() { return { type: "sm-init", scenarios: all(), users: users(), actors: playerActors(), catalogue: catalogueList(), world: game.world.title, settings: { goldPath: goldPath(), piPath: game.settings.get(MID, "piPath") } }; }
}
let tool = null;
function openTool() { if (!game.user.isGM) return ui.notifications.warn("Réservé au MJ."); if (!tool) tool = new ScenTool(); tool.render({ force: true }); return tool; }
window.addEventListener("message", async ev => {
  const m = ev.data; if (!m || !tool || ev.source !== tool.frame?.contentWindow) return;
  switch (m.type) {
    case "sm-ready": tool.post(tool.initData()); break;
    case "sm-save": await saveAll(m.scenarios || []); refreshJournals(); break;
    case "sm-broadcast": broadcast(m.scen, m.targets || "all", true); break;
    case "sm-status": {
      if (!game.settings.get(MID, "notifyStatus")) break; const s = m.scen; const st = C().STATUS[s.status] || s.status;
      const text = tpl(game.settings.get(MID, "statusText"), { titre: s.titre || s.cible || s.ref, type: C().TYPE_LABELS[s.type] || s.type, num: s.num, statut: st.toLowerCase() });
      notifyPlayers(text, s.status === "active" ? s : null); refreshJournals(); break; }
    case "sm-reward": { const r = await grantRewards(m); tool.post({ type: "sm-toast", text: r.map(x => `${x.actor} : ${m.gold || 0} G · ${m.pi || 0} P.I.${x.names.length ? " · " + x.names.join(", ") : ""}`).join("  |  ") || "Aucun personnage trouvé." }); tool.post({ type: "sm-actors", actors: playerActors() }); break; }
  }
});
Hooks.on("userConnected", () => { if (tool) tool.post({ type: "sm-users", users: users() }); });

/* ═══════════ journal des scénarios (joueurs & MJ) ═══════════ */
class ScenJournal extends ApplicationV2 {
  static DEFAULT_OPTIONS = { id: "sm-journal", classes: ["sm-journal"], window: { title: "Journal des scénarios", icon: "fa-solid fa-book-open", resizable: true }, position: { width: 900, height: 700 } };
  constructor(o) { super(o); this.filter = "all"; this.sel = null; }
  async _prepareContext() { return {}; }
  async _renderHTML() {
    const list = visibleFor(game.user).sort(C().compare); const f = this.filter;
    const shown = list.filter(s => f === "all" || (f === "active" ? s.status === "active" : f === "done" ? (s.status === "done" || s.status === "failed") : s.type === f));
    if (!this.sel || !shown.some(s => s.id === this.sel)) this.sel = shown[0]?.id || null;
    const root = document.createElement("div"); root.className = "sm-jbody";
    const types = [...new Set(list.map(s => s.type))];
    let side = `<div class="sm-jfilters"><button data-f="all" class="${f === "all" ? "on" : ""}">Tous</button><button data-f="active" class="${f === "active" ? "on" : ""}">En cours</button>${game.settings.get(MID, "playersSeeDone") || game.user.isGM ? `<button data-f="done" class="${f === "done" ? "on" : ""}">Terminés</button>` : ""}${types.map(t => `<button data-f="${t}" class="${f === t ? "on" : ""}">${C().TYPE_SHORT[t]}</button>`).join("")}</div><div class="sm-jlist">`;
    let last = null;
    if (!shown.length) side += `<div class="sm-jempty">AUCUN SCÉNARIO<br>pour l'instant</div>`;
    for (const s of shown) { if (s.type !== last) { last = s.type; side += `<div class="sm-jgroup">${C().TYPE_LABELS[s.type]}</div>`; } side += `<div class="sm-jrow rank-${s.rang.toLowerCase()} ${s.id === this.sel ? "on" : ""}" data-id="${s.id}"><div class="r">${s.rang}</div><div class="t"><b>${s.type === "PRINCIPAL" ? "N°" + s.num + " · " : ""}${foundry.utils.escapeHTML(s.titre || s.cible || s.ref)}</b><small>${C().TYPE_SHORT[s.type]} · ${C().worldRef(s)[1]}</small></div><span class="st ${s.status}">${C().STATUS[s.status]}</span></div>`; }
    side += `</div>`;
    const cur = shown.find(s => s.id === this.sel);
    root.innerHTML = `<div>${side}</div><div class="sm-jview">${cur ? C().html(cur, { cls: "journal" }) : `<div class="sm-jempty">Sélectionne un scénario</div>`}</div>`;
    root.querySelectorAll(".sm-jrow").forEach(el => el.addEventListener("click", () => { this.sel = el.dataset.id; this.render(false); }));
    root.querySelectorAll(".sm-jfilters button").forEach(b => b.addEventListener("click", () => { this.filter = b.dataset.f; this.render(false); }));
    return root;
  }
  _replaceHTML(r, c) { c.replaceChildren(r); }
}
let journal = null;
function openJournal() { if (!game.user.isGM && !game.settings.get(MID, "playersCanOpen")) return ui.notifications.warn("Le journal des scénarios est fermé par le MJ."); if (!journal) journal = new ScenJournal(); journal.render({ force: true }); return journal; }
function refreshJournals() { if (journal?.rendered) journal.render(false); }
Hooks.on("updateSetting", s => { if (s.key === `${MID}.scenarios`) { refreshJournals(); if (tool) tool.post({ type: "sm-scenarios", scenarios: all() }); } });

/* ═══════════ boutons ═══════════ */
Hooks.on("getSceneControlButtons", controls => {
  const mk = (name, title, icon, fn) => ({ name, title, icon, button: true, order: 98, onChange: fn, onClick: fn });
  const tools = []; if (game.user.isGM) tools.push(mk("sm-tool", "Scénarios Manhwa — Tableau (MJ)", "fa-solid fa-scroll", openTool));
  if (game.user.isGM || game.settings.get(MID, "playersCanOpen")) tools.push(mk("sm-journal", "Journal des scénarios", "fa-solid fa-book-open", openJournal));
  if (Array.isArray(controls)) { const c = controls.find(x => x.name === "notes") || controls[0]; tools.forEach(t => c.tools.push(t)); }
  else { const c = controls.notes || controls.tokens; if (c) tools.forEach(t => { c.tools[t.name] = t; }); }
});
Hooks.on("renderJournalDirectory", (dir, html) => {
  const root = html instanceof HTMLElement ? html : html[0]; if (root.querySelector(".sm-btn")) return;
  const header = root.querySelector(".directory-header") || root.querySelector("header") || root;
  if (game.user.isGM || game.settings.get(MID, "playersCanOpen")) { const b = document.createElement("button"); b.className = "sm-btn"; b.innerHTML = '<i class="fa-solid fa-book-open"></i> Journal des scénarios'; b.addEventListener("click", openJournal); header.appendChild(b); }
  if (game.user.isGM) { const b2 = document.createElement("button"); b2.className = "sm-btn"; b2.innerHTML = '<i class="fa-solid fa-scroll"></i> Scénarios — Tableau MJ'; b2.addEventListener("click", openTool); header.appendChild(b2); }
});

Hooks.once("ready", () => {
  game.socket.on(SOCKET, receive);
  const mod = game.modules.get(MID);
  mod.api = {
    open: openTool, openJournal, all, visible: () => visibleFor(game.user),
    /** Affiche un scénario (objet ou id) à tous ou à des joueurs donnés. */
    show: (scen, targets = "all") => { const s = typeof scen === "string" ? all().find(x => x.id === scen) : scen; if (s) broadcast(s, targets, true); },
    /** Change le statut d'un scénario par id : 'upcoming' | 'active' | 'done' | 'failed'. */
    setStatus: async (id, status) => { const list = all(); const s = list.find(x => x.id === id); if (!s) return; s.status = status; s.up = Date.now(); await saveAll(list); },
    grant: grantRewards, card: (s, o) => C().html(s, o)
  };
  console.log(`${MID} | prêt`);
});
